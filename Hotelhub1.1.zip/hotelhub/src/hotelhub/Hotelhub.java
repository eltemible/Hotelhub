package hotelhub;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Hotelhub extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3260537878027944156L;
	private JPanel contentPane;
	private JTextField textField_2;
	private JTextField txtRegister;
	private JTextField txtUsername;
	private JTextField txtPassword;
	private JTextField txtPassword_1;
	private JTextField txtAlreadyRegistered;
	private JTextField txtApellido;
	private JTextField txtApellido_1;
	private JTextField txtContrasea;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTextField textField_4;
	private JPasswordField passwordField;
	private JTextField txtHotelhub;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Hotelhub frame = new Hotelhub();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Hotelhub() {
		
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 102, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(74, 48, 86, 20);
		contentPane.add(textField_2);

		txtRegister = new JTextField();
		txtRegister.setBorder(null);
		txtRegister.setFont(new Font("Tahoma", Font.PLAIN, 24));
		txtRegister.setForeground(new Color(255, 255, 255));
		txtRegister.setEditable(false);
		txtRegister.setBackground(new Color(0, 102, 255));
		txtRegister.setText("REGISTER");
		txtRegister.setBounds(253, 11, 117, 44);
		contentPane.add(txtRegister);
		txtRegister.setColumns(10);

		txtUsername = new JTextField();
		txtUsername.setForeground(new Color(255, 255, 255));
		txtUsername.setCaretColor(new Color(255, 255, 255));
		txtUsername.setBorder(null);
		txtUsername.setBackground(new Color(0, 102, 255));
		txtUsername.setEditable(false);
		txtUsername.setText("usuario");
		txtUsername.setBounds(10, 48, 86, 20);
		contentPane.add(txtUsername);
		txtUsername.setColumns(10);

		txtPassword = new JTextField();
		txtPassword.setForeground(new Color(255, 255, 255));
		txtPassword.setBorder(null);
		txtPassword.setBackground(new Color(0, 102, 255));
		txtPassword.setEditable(false);
		txtPassword.setText("Nombre");
		txtPassword.setBounds(10, 79, 54, 20);
		contentPane.add(txtPassword);
		txtPassword.setColumns(10);

		txtPassword_1 = new JTextField();
		txtPassword_1.setForeground(new Color(255, 255, 255));
		txtPassword_1.setBorder(null);
		txtPassword_1.setBackground(new Color(0, 102, 255));
		txtPassword_1.setEditable(false);
		txtPassword_1.setText("email");
		txtPassword_1.setBounds(10, 173, 54, 20);
		contentPane.add(txtPassword_1);
		txtPassword_1.setColumns(10);

		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Conexion c = new Conexion();
				c.Conectar();
			    try {
					c.EjecutarUpdate("INSERT INTO `clientes` (`Apellido`,`Apellido2`, `contrasenna`, `email`, `Nombre`, `usuario`) VALUES ('" + textField_1.getText() + "', '" + textField_3.getText()  + "', '" + passwordField.getText() +"', '" + textField_4.getText() + "', '" + textField.getText() + "', '" + textField_2.getText() + "')");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnRegister.setBounds(261, 92, 89, 23);
		contentPane.add(btnRegister);

		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnLogin.setBounds(345, 237, 89, 23);
		contentPane.add(btnLogin);

		txtAlreadyRegistered = new JTextField();
		txtAlreadyRegistered.setEditable(false);
		txtAlreadyRegistered.setForeground(new Color(255, 255, 255));
		txtAlreadyRegistered.setBorder(null);
		txtAlreadyRegistered.setBackground(new Color(0, 102, 255));
		txtAlreadyRegistered.setText("Already registered?");
		txtAlreadyRegistered.setBounds(218, 238, 117, 20);
		contentPane.add(txtAlreadyRegistered);
		txtAlreadyRegistered.setColumns(10);

		txtApellido = new JTextField();
		txtApellido.setForeground(new Color(255, 255, 255));
		txtApellido.setCaretColor(new Color(255, 255, 255));
		txtApellido.setBorder(null);
		txtApellido.setBackground(new Color(0, 102, 255));
		txtApellido.setEditable(false);
		txtApellido.setText("Apellido");
		txtApellido.setBounds(10, 110, 54, 20);
		contentPane.add(txtApellido);
		txtApellido.setColumns(10);

		txtApellido_1 = new JTextField();
		txtApellido_1.setEditable(false);
		txtApellido_1.setForeground(new Color(255, 255, 255));
		txtApellido_1.setBorder(null);
		txtApellido_1.setBackground(new Color(0, 102, 255));
		txtApellido_1.setText("Apellido2");
		txtApellido_1.setBounds(10, 142, 64, 20);
		contentPane.add(txtApellido_1);
		txtApellido_1.setColumns(10);

		txtContrasea = new JTextField();
		txtContrasea.setBorder(null);
		txtContrasea.setBackground(new Color(0, 102, 255));
		txtContrasea.setForeground(new Color(255, 255, 255));
		txtContrasea.setEditable(false);
		txtContrasea.setText("contrase\u00F1a");
		txtContrasea.setBounds(10, 204, 64, 20);
		contentPane.add(txtContrasea);
		txtContrasea.setColumns(10);

		textField = new JTextField();
		textField.setBounds(74, 79, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(74, 110, 86, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		textField_3 = new JTextField();
		textField_3.setBounds(74, 141, 86, 20);
		contentPane.add(textField_3);
		textField_3.setColumns(10);

		textField_4 = new JTextField();
		textField_4.setBounds(74, 173, 86, 20);
		contentPane.add(textField_4);
		textField_4.setColumns(10);

		passwordField = new JPasswordField();
		passwordField.setBounds(74, 204, 86, 20);
		contentPane.add(passwordField);

		txtHotelhub = new JTextField();
		txtHotelhub.setFont(new Font("Tahoma", Font.PLAIN, 17));
		txtHotelhub.setForeground(new Color(255, 255, 255));
		txtHotelhub.setBorder(null);
		txtHotelhub.setBackground(new Color(0, 102, 255));
		txtHotelhub.setText("HOTELHUB");
		txtHotelhub.setBounds(264, 66, 86, 20);
		contentPane.add(txtHotelhub);
		txtHotelhub.setColumns(10);

	}
	
	/*INSERT INTO `clientes` (`Nombre`, `Apellido`, `Apellido2`, `email`, `usuario`, `contrase�a`) VALUES ('juan', 'lora', 'ruiz', 'mimenteesunica@gmail.com', 'mimenteesunica', '12345');*/
}
