package hotelhub;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPasswordField;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JMenu;
import javax.swing.SwingConstants;
import javax.swing.DropMode;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.SpinnerNumberModel;

public class Habitaciones extends JFrame {

	private JPanel contentPane;
	private JTextField txtNcamas;
	private JTextField txtTipoDeHabitacion;
	private JTextField txtextras;
	private JTextField txtDisfrutaDeTu;
	private JTextField txtHotelhub;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Habitaciones frame = new Habitaciones();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Habitaciones() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 102, 255));
		contentPane.setBorder(null);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtNcamas = new JTextField();
		txtNcamas.setForeground(new Color(255, 255, 255));
		txtNcamas.setBorder(null);
		txtNcamas.setBackground(new Color(0, 102, 255));
		txtNcamas.setEditable(false);
		txtNcamas.setText("N\u00BAcamas");
		txtNcamas.setBounds(34, 29, 86, 20);
		contentPane.add(txtNcamas);
		txtNcamas.setColumns(10);
		
		JSpinner spinner = new JSpinner();
		spinner.setModel(new SpinnerNumberModel(1, 1, 4, 1));
		spinner.setBackground(new Color(0, 102, 255));
		spinner.setBounds(130, 29, 45, 20);
		contentPane.add(spinner);
		
		txtTipoDeHabitacion = new JTextField();
		txtTipoDeHabitacion.setForeground(new Color(255, 255, 255));
		txtTipoDeHabitacion.setBorder(null);
		txtTipoDeHabitacion.setBackground(new Color(0, 102, 255));
		txtTipoDeHabitacion.setEditable(false);
		txtTipoDeHabitacion.setText("Tipo de habitacion");
		txtTipoDeHabitacion.setBounds(34, 66, 125, 20);
		contentPane.add(txtTipoDeHabitacion);
		txtTipoDeHabitacion.setColumns(10);
		
		txtextras = new JTextField();
		txtextras.setForeground(new Color(255, 255, 255));
		txtextras.setDisabledTextColor(new Color(255, 255, 255));
		txtextras.setBorder(null);
		txtextras.setBackground(new Color(0, 102, 255));
		txtextras.setEditable(false);
		txtextras.setText("\u00BFExtras?");
		txtextras.setBounds(34, 176, 51, 20);
		contentPane.add(txtextras);
		txtextras.setColumns(10);
		
		JRadioButton rdbtnSi = new JRadioButton("SI");
		rdbtnSi.setBackground(new Color(0, 102, 255));
		rdbtnSi.setBounds(34, 203, 40, 23);
		contentPane.add(rdbtnSi);
		
		JRadioButton rdbtnNo = new JRadioButton("NO");
		rdbtnNo.setBackground(new Color(0, 102, 255));
		rdbtnNo.setBounds(34, 231, 51, 23);
		contentPane.add(rdbtnNo);
		
		JCheckBox chckbxNormal = new JCheckBox("Normal");
		chckbxNormal.setBackground(new Color(0, 102, 255));
		chckbxNormal.setBounds(34, 119, 86, 23);
		contentPane.add(chckbxNormal);
		
		JCheckBox chckbxBarata = new JCheckBox("Barata");
		chckbxBarata.setBackground(new Color(0, 102, 255));
		chckbxBarata.setBounds(34, 93, 86, 23);
		contentPane.add(chckbxBarata);
		
		JCheckBox chckbxLujo = new JCheckBox("Lujo");
		chckbxLujo.setBackground(new Color(0, 102, 255));
		chckbxLujo.setBounds(34, 144, 86, 23);
		contentPane.add(chckbxLujo);
		
		txtDisfrutaDeTu = new JTextField();
		txtDisfrutaDeTu.setEditable(false);
		txtDisfrutaDeTu.setForeground(new Color(255, 255, 255));
		txtDisfrutaDeTu.setBackground(new Color(0, 102, 255));
		txtDisfrutaDeTu.setBorder(null);
		txtDisfrutaDeTu.setFont(new Font("Trajan Pro", Font.PLAIN, 15));
		txtDisfrutaDeTu.setText("DISFRUTA DE TU HABITACI\u00D3N");
		txtDisfrutaDeTu.setBounds(204, 143, 219, 20);
		contentPane.add(txtDisfrutaDeTu);
		txtDisfrutaDeTu.setColumns(10);
		
		txtHotelhub = new JTextField();
		txtHotelhub.setForeground(new Color(255, 255, 255));
		txtHotelhub.setEditable(false);
		txtHotelhub.setBorder(null);
		txtHotelhub.setBackground(new Color(0, 102, 255));
		txtHotelhub.setText("HOTELHUB");
		txtHotelhub.setBounds(281, 176, 86, 20);
		contentPane.add(txtHotelhub);
		txtHotelhub.setColumns(10);
	}
}
