package funciones;

import hotelhub.Conexion;

public class Funciones {
	
	public static boolean consultarLogin(String user, String pssw) {
		
		Conexion c = new Conexion();
		c.Conectar();
		String[] password = c.EjecutarSentencia("SELECT Contrasenna FROM clientes WHERE Usuario LIKE('" + user + "')", "Contrasenna");
		if (password[0].equals(pssw)) {
			return true;
		} else {			
			return false;
		}
		
	}

}
