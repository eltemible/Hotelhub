package hotelhub;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import funciones.Funciones;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField txtUsuario;
	private JPasswordField Contrase�a;
	private JTextField txtContrasea;
	private JTextField txtLogin;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 102, 255));
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(165, 85, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		
		JButton botonlogin = new JButton("Login");
		botonlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				//metodo de login
				System.out.println(Funciones.consultarLogin(textField.getText(), Contrase�a.getText()));
				if (Funciones.consultarLogin(textField.getText(), Contrase�a.getText())) {
					
					JOptionPane.showMessageDialog(null, "Bienvenido");

					Habitaciones nuevaVentana = new Habitaciones();
					nuevaVentana.setVisible(true);
					dispose();
					
				} else {
					JOptionPane.showMessageDialog(null, "Error, datos incompletos o erroneos");

				}
			}
			
		});
		botonlogin.setBounds(165, 210, 89, 23);
		contentPane.add(botonlogin);
		
		txtUsuario = new JTextField();
		txtUsuario.setBorder(null);
		txtUsuario.setBackground(new Color(0, 102, 255));
		txtUsuario.setEditable(false);
		txtUsuario.setText("Usuario");
		txtUsuario.setBounds(182, 62, 86, 20);
		contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		Contrase�a = new JPasswordField();
		Contrase�a.setBounds(165, 156, 86, 20);
		contentPane.add(Contrase�a);
		
		txtContrasea = new JTextField();
		txtContrasea.setBorder(null);
		txtContrasea.setBackground(new Color(0, 102, 255));
		txtContrasea.setEditable(false);
		txtContrasea.setText("Contrase\u00F1a");
		txtContrasea.setBounds(175, 125, 86, 20);
		contentPane.add(txtContrasea);
		txtContrasea.setColumns(10);
		
		txtLogin = new JTextField();
		txtLogin.setFont(new Font("Tahoma", Font.PLAIN, 26));
		txtLogin.setForeground(new Color(255, 255, 255));
		txtLogin.setBorder(null);
		txtLogin.setBackground(new Color(0, 102, 255));
		txtLogin.setEditable(false);
		txtLogin.setText("Login");
		txtLogin.setBounds(174, 11, 80, 40);
		contentPane.add(txtLogin);
		txtLogin.setColumns(10);
	}

}
