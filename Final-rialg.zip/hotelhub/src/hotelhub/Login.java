package hotelhub;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField txtUsuario;
	private JPasswordField Contrase�a;
	private JTextField txtContrasea;
	private JTextField txtLogin;
	private JButton btnRegistros;
	private JSeparator separator;
	private JSeparator separator_1;
	private JButton btnRegistrate;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setResizable(false);
		Conexion c = new Conexion();
		c.Conectar();
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 102, 255));
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(165, 85, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		
		JButton botonlogin = new JButton("Login");
		botonlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				/*metodo de login
				System.out.println(Funciones.consultarLogin(textField.getText(), Contrase�a.getText()));
				*/
				dispose();
				System.out.println(
                        "SELECT usuario , contrasenna FROM clientes "+
                        "WHERE usuario= '" + textField.getText()  +
                        "'AND contrasenna='" + Contrase�a.getText()+"'");
				ResultSet resultado = Conexion.EjecutarSentencia(
                        "SELECT usuario,contrasenna FROM clientes "+
                        "WHERE usuario = '" + textField.getText()  +
                        "'AND contrasenna='" + Contrase�a.getText()+"'");

                try {

                    if (resultado.next()){

                        Habitaciones i = new Habitaciones();
                        i.setVisible(true);

                    }else {

                        dispose();
                        JOptionPane.showMessageDialog(null, "Tu nombre de usuario o contrase�a no son correctos ", "ERROR", JOptionPane.OK_OPTION);
                        Login l = new Login();
                        l.setVisible(true);

                    }
                } catch (HeadlessException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }

        }
				
				

				
							
		});
		botonlogin.setBounds(165, 180, 89, 23);
		contentPane.add(botonlogin);
		
		txtUsuario = new JTextField();
		txtUsuario.setForeground(new Color(248, 248, 255));
		txtUsuario.setBorder(null);
		txtUsuario.setBackground(new Color(0, 102, 255));
		txtUsuario.setEditable(false);
		txtUsuario.setText("Usuario");
		txtUsuario.setBounds(181, 64, 86, 20);
		contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		Contrase�a = new JPasswordField();
		Contrase�a.setBounds(165, 136, 86, 20);
		contentPane.add(Contrase�a);
		
		txtContrasea = new JTextField();
		txtContrasea.setForeground(new Color(248, 248, 255));
		txtContrasea.setBorder(null);
		txtContrasea.setBackground(new Color(0, 102, 255));
		txtContrasea.setEditable(false);
		txtContrasea.setText("Contrase\u00F1a");
		txtContrasea.setBounds(175, 116, 86, 20);
		contentPane.add(txtContrasea);
		txtContrasea.setColumns(10);
		
		txtLogin = new JTextField();
		txtLogin.setFont(new Font("Tahoma", Font.PLAIN, 26));
		txtLogin.setForeground(new Color(255, 255, 255));
		txtLogin.setBorder(null);
		txtLogin.setBackground(new Color(0, 102, 255));
		txtLogin.setEditable(false);
		txtLogin.setText("Login");
		txtLogin.setBounds(171, 11, 80, 32);
		contentPane.add(txtLogin);
		txtLogin.setColumns(10);
		
		btnRegistros = new JButton("AdminPanel");
		btnRegistros.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Paneladmin nuevaVentana = new Paneladmin();
				nuevaVentana.setVisible(true);
				Login.this.dispose();	
								
			}
		});
		btnRegistros.setBounds(244, 227, 126, 23);
		contentPane.add(btnRegistros);
		
		separator = new JSeparator();
		separator.setBounds(75, 49, 267, 2);
		contentPane.add(separator);
		
		separator_1 = new JSeparator();
		separator_1.setBounds(75, 214, 267, 2);
		contentPane.add(separator_1);
		
		btnRegistrate = new JButton("Registrate");
		btnRegistrate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Hotelhub nuevaVentana = new Hotelhub();
				nuevaVentana.setVisible(true);
				Login.this.dispose();
			}
		});
		btnRegistrate.setBounds(75, 227, 126, 23);
		contentPane.add(btnRegistrate);
	}

}
