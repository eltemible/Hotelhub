package hotelhub;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPasswordField;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JMenu;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.DropMode;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.SpinnerNumberModel;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.ButtonGroup;
import javax.swing.border.TitledBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.JSeparator;
import javax.swing.JComboBox;
import java.awt.Window.Type;

public class Actualizar2 extends JFrame {

	private JPanel contentPane;
	private JTextField Ncamas;
	private JTextField txtTipoDeHabitacion;
	private JTextField txtextras;
	private final ButtonGroup tipo = new ButtonGroup();
	private final ButtonGroup extras = new ButtonGroup();
	private JTextField nombre;
	private JTextField txtNombreDeUsuario_1;
	private JComboBox comboBox3;

	public Actualizar2() {
		setType(Type.POPUP);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 295, 255);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(135, 206, 250));
		contentPane.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Ncamas = new JTextField();
		Ncamas.setForeground(new Color(0, 0, 0));
		Ncamas.setBorder(null);
		Ncamas.setBackground(new Color(135, 206, 250));
		Ncamas.setEditable(false);
		Ncamas.setText("N\u00BAcamas");
		Ncamas.setBounds(168, 82, 86, 20);
		contentPane.add(Ncamas);
		Ncamas.setColumns(10);
		
		
		
		
		
		txtTipoDeHabitacion = new JTextField();
		txtTipoDeHabitacion.setForeground(new Color(0, 0, 0));
		txtTipoDeHabitacion.setBorder(null);
		txtTipoDeHabitacion.setBackground(new Color(135, 206, 250));
		txtTipoDeHabitacion.setEditable(false);
		txtTipoDeHabitacion.setText("Tipo de habitacion");
		txtTipoDeHabitacion.setBounds(14, 82, 125, 20);
		contentPane.add(txtTipoDeHabitacion);
		txtTipoDeHabitacion.setColumns(10);
		
		txtextras = new JTextField();
		txtextras.setForeground(new Color(0, 0, 0));
		txtextras.setDisabledTextColor(new Color(255, 255, 255));
		txtextras.setBorder(null);
		txtextras.setBackground(new Color(135, 206, 250));
		txtextras.setEditable(false);
		txtextras.setText("\u00BFExtras?");
		txtextras.setBounds(168, 23, 51, 20);
		contentPane.add(txtextras);
		txtextras.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(14, 115, 105, 20);
		comboBox.addItem("Barato(10-25�)");
		comboBox.addItem("Normal(25-50�)");
		comboBox.addItem("Lujo(+100�)");

		contentPane.add(comboBox);
		
		JComboBox comboBox2 = new JComboBox();
		comboBox2.setBounds(168, 41, 51, 20);		
		comboBox2.addItem("Si");
		comboBox2.addItem("No");
		contentPane.add(comboBox2);				
		
		
		
		comboBox3 = new JComboBox();
		comboBox3.setBounds(168, 113, 45, 23);
		comboBox3.addItem("1");
		comboBox3.addItem("2");
		comboBox3.addItem("3");
		comboBox3.addItem("4");
		contentPane.add(comboBox3);
		
		//Reservar hotel
		
		
		//INSERT INTO `habitaciones` (`Ncamas`, `tipo`, `extras`, `usuario`) VALUES ('1', '2', 'Lujo', 'si', NULL)

		
		
		JButton btnReservar = new JButton("Actualizar");
		btnReservar.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnReservar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				
//******************************************************//
					//ERROR
					//ERROR
					//ERROR


			Conexion c = new Conexion();
			c.Conectar();
			try {
				dispose();
				/*System.out.println("INSERT INTO habitaciones (tipo, extras, Ncamas, usuario) "
                        + "VALUES "
                        + "('" + comboBox.getSelectedItem() + 
                         "','" + comboBox2.getSelectedItem() + 
                         "','" + comboBox3.getSelectedItem() + 
                        "', '" + nombre.getText() +
                        "')");*/
				c.EjecutarUpdate("DELETE FROM habitaciones WHERE usuario = \"" + nombre.getText() + "\"");
				c.EjecutarUpdate("INSERT INTO habitaciones (tipo, extras, Ncamas, usuario) "
                        + "VALUES "
                        + "('" + comboBox.getSelectedItem() + 
                         "','" + comboBox2.getSelectedItem() + 
                         "','" + comboBox3.getSelectedItem() + 
                        "', '" + nombre.getText() +
                        "')");
				JOptionPane.showMessageDialog(null, "Sus datos han sido actualizados correctamente!!");

				UsuariosRegistrados2 ur2 = new UsuariosRegistrados2();
                ur2.setVisible(true);

                
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
					//ERROR
					//ERROR
					//ERROR

//******************************************************//

			
			}
		});
		btnReservar.setBounds(87, 165, 89, 23);
		contentPane.add(btnReservar);
		
		nombre = new JTextField();
		nombre.setBounds(14, 41, 105, 20);
		contentPane.add(nombre);
		nombre.setColumns(10);
		
		txtNombreDeUsuario_1 = new JTextField();
		txtNombreDeUsuario_1.setForeground(new Color(0, 0, 0));
		txtNombreDeUsuario_1.setBorder(null);
		txtNombreDeUsuario_1.setBackground(new Color(135, 206, 250));
		txtNombreDeUsuario_1.setEditable(false);
		txtNombreDeUsuario_1.setText("Nombre de usuario");
		txtNombreDeUsuario_1.setBounds(14, 23, 125, 20);
		contentPane.add(txtNombreDeUsuario_1);
		txtNombreDeUsuario_1.setColumns(10);
		


		

		
		
		
		
		
	}
}

