package hotelhub;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;

public class Hotelhub extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3260537878027944156L;
	private JPanel contentPane;
	private JTextField usuario;
	private JTextField txtRegister;
	private JTextField txtUsername;
	private JTextField txtPassword;
	private JTextField txtPassword_1;
	private JTextField txtAlreadyRegistered;
	private JTextField txtApellido;
	private JTextField txtApellido_1;
	private JTextField txtContrasea;
	private JTextField nombre;
	private JTextField apellido1;
	private JTextField apellido2;
	private JTextField email;
	private JPasswordField pass;
	private JTextField txtHotelhub;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public Hotelhub() {
		
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 102, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		usuario = new JTextField();
		usuario.setColumns(10);
		usuario.setBounds(74, 48, 86, 20);
		contentPane.add(usuario);

		txtRegister = new JTextField();
		txtRegister.setBorder(null);
		txtRegister.setFont(new Font("Tahoma", Font.PLAIN, 24));
		txtRegister.setForeground(new Color(255, 255, 255));
		txtRegister.setEditable(false);
		txtRegister.setBackground(new Color(0, 102, 255));
		txtRegister.setText("REGISTER");
		txtRegister.setBounds(267, 41, 117, 44);
		contentPane.add(txtRegister);
		txtRegister.setColumns(10);

		txtUsername = new JTextField();
		txtUsername.setForeground(new Color(255, 255, 255));
		txtUsername.setCaretColor(new Color(255, 255, 255));
		txtUsername.setBorder(null);
		txtUsername.setBackground(new Color(0, 102, 255));
		txtUsername.setEditable(false);
		txtUsername.setText("usuario");
		txtUsername.setBounds(10, 48, 86, 20);
		contentPane.add(txtUsername);
		txtUsername.setColumns(10);

		txtPassword = new JTextField();
		txtPassword.setForeground(new Color(255, 255, 255));
		txtPassword.setBorder(null);
		txtPassword.setBackground(new Color(0, 102, 255));
		txtPassword.setEditable(false);
		txtPassword.setText("Nombre");
		txtPassword.setBounds(10, 79, 54, 20);
		contentPane.add(txtPassword);
		txtPassword.setColumns(10);

		txtPassword_1 = new JTextField();
		txtPassword_1.setForeground(new Color(255, 255, 255));
		txtPassword_1.setBorder(null);
		txtPassword_1.setBackground(new Color(0, 102, 255));
		txtPassword_1.setEditable(false);
		txtPassword_1.setText("email");
		txtPassword_1.setBounds(10, 173, 54, 20);
		contentPane.add(txtPassword_1);
		txtPassword_1.setColumns(10);

		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Conexion c = new Conexion();
				c.Conectar();
				
				if(
						usuario.getText().length()>=2 && 
						pass.getText().length()>=2 && 
						nombre.getText().length()>=2 && 
						apellido1.getText().length()>=2 &&
						apellido2.getText().length()>=2 &&
						email.getText().length()>=2) {
			    try {
					c.EjecutarUpdate("INSERT INTO `clientes` (`Apellido`,`Apellido2`, `contrasenna`, `email`, `Nombre`, `usuario`) "
							+ "VALUES "
							+ "('" + apellido1.getText() + 
							"', '" + apellido2.getText()  + 
							"', '" + pass.getText() +
							"', '" + email.getText() + 
							"', '" + nombre.getText() +
							"', '" + usuario.getText() + "')");
					JOptionPane.showMessageDialog(null, "Te has registrado correctamente");

				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			    
				}else {
					JOptionPane.showMessageDialog(null, "Error, datos incompletos o erroneos");

				}
			}
		});
		btnRegister.setBounds(281, 127, 89, 23);
		contentPane.add(btnRegister);
		
		//Bot�n login
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			Login nuevaVentana = new Login();
			nuevaVentana.setVisible(true);
			Hotelhub.this.dispose();				
			}
		});
		btnLogin.setBounds(345, 237, 89, 23);
		contentPane.add(btnLogin);

		txtAlreadyRegistered = new JTextField();
		txtAlreadyRegistered.setEditable(false);
		txtAlreadyRegistered.setForeground(new Color(255, 255, 255));
		txtAlreadyRegistered.setBorder(null);
		txtAlreadyRegistered.setBackground(new Color(0, 102, 255));
		txtAlreadyRegistered.setText("Already registered?");
		txtAlreadyRegistered.setBounds(218, 238, 117, 20);
		contentPane.add(txtAlreadyRegistered);
		txtAlreadyRegistered.setColumns(10);

		txtApellido = new JTextField();
		txtApellido.setForeground(new Color(255, 255, 255));
		txtApellido.setCaretColor(new Color(255, 255, 255));
		txtApellido.setBorder(null);
		txtApellido.setBackground(new Color(0, 102, 255));
		txtApellido.setEditable(false);
		txtApellido.setText("Apellido");
		txtApellido.setBounds(10, 110, 54, 20);
		contentPane.add(txtApellido);
		txtApellido.setColumns(10);

		txtApellido_1 = new JTextField();
		txtApellido_1.setEditable(false);
		txtApellido_1.setForeground(new Color(255, 255, 255));
		txtApellido_1.setBorder(null);
		txtApellido_1.setBackground(new Color(0, 102, 255));
		txtApellido_1.setText("Apellido2");
		txtApellido_1.setBounds(10, 142, 64, 20);
		contentPane.add(txtApellido_1);
		txtApellido_1.setColumns(10);

		txtContrasea = new JTextField();
		txtContrasea.setBorder(null);
		txtContrasea.setBackground(new Color(0, 102, 255));
		txtContrasea.setForeground(new Color(255, 255, 255));
		txtContrasea.setEditable(false);
		txtContrasea.setText("contrase\u00F1a");
		txtContrasea.setBounds(10, 204, 64, 20);
		contentPane.add(txtContrasea);
		txtContrasea.setColumns(10);

		nombre = new JTextField();
		nombre.setBounds(74, 79, 86, 20);
		contentPane.add(nombre);
		nombre.setColumns(10);

		apellido1 = new JTextField();
		apellido1.setBounds(74, 110, 86, 20);
		contentPane.add(apellido1);
		apellido1.setColumns(10);

		apellido2 = new JTextField();
		apellido2.setBounds(74, 141, 86, 20);
		contentPane.add(apellido2);
		apellido2.setColumns(10);

		email = new JTextField();
		email.setBounds(74, 173, 86, 20);
		contentPane.add(email);
		email.setColumns(10);

		pass = new JPasswordField();
		pass.setBounds(74, 204, 86, 20);
		contentPane.add(pass);

		txtHotelhub = new JTextField();
		txtHotelhub.setFont(new Font("Tahoma", Font.PLAIN, 17));
		txtHotelhub.setForeground(new Color(255, 255, 255));
		txtHotelhub.setBorder(null);
		txtHotelhub.setBackground(new Color(0, 102, 255));
		txtHotelhub.setText("HOTELHUB");
		txtHotelhub.setBounds(281, 96, 86, 20);
		contentPane.add(txtHotelhub);
		txtHotelhub.setColumns(10);

	}
}
