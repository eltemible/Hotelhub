package hotelhub;

import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.JTextField;
import javax.swing.border.CompoundBorder;
import javax.swing.border.LineBorder;

public class UsuariosRegistrados2 extends JFrame {

	
	private static final long serialVersionUID = 2076441793193688952L;
	private JPanel contentPane;
	private JTable tabla1;
	private JTextField textField;
	private JTextField txtIntroduzcaElUsuario;
	private JTextField txtQueQuieraBorrar;


	/**
	 * Create the frame.
	 */
	public UsuariosRegistrados2() {
		Conexion c = new Conexion();
		c.Conectar();
		setResizable(false);
		setFocusable(false);
		setTitle("https://www.hotelhub.com/reservas");
		setIconImage(Toolkit.getDefaultToolkit().getImage(""));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(650, 300, 783, 496);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(135, 206, 250));
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton btnVolver = new JButton("Cerrar sesion");
		btnVolver.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnVolver.setBackground(new Color(135, 206, 250));
		btnVolver.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				dispose();
				Login l = new Login();
				l.setVisible(true);

				
			}
		});
		
		
		btnVolver.setBounds(559, 11, 89, 23);
		panel.add(btnVolver);
		
		JTextArea txtrVisualizacionDelListado = new JTextArea();
		txtrVisualizacionDelListado.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtrVisualizacionDelListado.setEditable(false);
		txtrVisualizacionDelListado.setBackground(new Color(135, 206, 250));
		txtrVisualizacionDelListado.setForeground(Color.BLACK);
		txtrVisualizacionDelListado.setText("RESERVAS");
		txtrVisualizacionDelListado.setBounds(336, 11, 325, 28);
		panel.add(txtrVisualizacionDelListado);
		
		
		DefaultTableModel modelo = new DefaultTableModel();
		tabla1 = new JTable(modelo);
		tabla1.setEnabled(false);
		tabla1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tabla1.setBackground(Color.LIGHT_GRAY);
		tabla1.setBounds(10, 69, 706, 305);
		panel.add(tabla1);
		
		modelo.addColumn("Ncamas");
		modelo.addColumn("Tipo");
		modelo.addColumn("Extras");
		modelo.addColumn("Usuario");
		
		dispose();
		ResultSet rs = Conexion.EjecutarSentencia("SELECT Ncamas, tipo, extras, usuario FROM habitaciones");
		
		try {
			while(rs.next()) {
				String[] filas = new String[4];
				for(int i = 0 ; i < 4 ; i++) {
					filas[i] = rs.getString(i+1);
				}
				modelo.addRow(filas);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		JScrollPane scrollBar = new JScrollPane(tabla1);
		scrollBar.setBackground(new Color(135, 206, 250));
		scrollBar.setBounds(10, 50, 555, 336);
		panel.add(scrollBar);
		scrollBar.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		JButton btnNuevoUsuario = new JButton("Nueva reserva");
		btnNuevoUsuario.setBackground(new Color(135, 206, 250));
		btnNuevoUsuario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Actualizar nuevaVentana = new Actualizar();
				nuevaVentana.setVisible(true);
				
			}
		});
		btnNuevoUsuario.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnNuevoUsuario.setBounds(606, 79, 132, 23);
		panel.add(btnNuevoUsuario);
		
		JButton btnNewButton = 	new JButton("Borrar reserva");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if (textField.getText().length() > 1) {
					
					dispose();
					
					int respuesta = JOptionPane.showConfirmDialog(null, "Quieres borrar esta reserva? ", "Borrando reserva...",JOptionPane.YES_NO_OPTION);		
					
					 if (respuesta==JOptionPane.NO_OPTION) {
						 dispose();
						 
					 }else if(respuesta==JOptionPane.YES_OPTION) {
					 
					try {
	
						//System.out.println("DELETE FROM listado_soldados WHERE DNI = " + dni.getText());
						JOptionPane.showMessageDialog(null, "Reserva anulada ", "Borrando datos de usuario...",JOptionPane.OK_OPTION);
						System.out.println("DELETE FROM habitaciones WHERE usuario = \"" + textField.getText() + "\"");
						c.EjecutarUpdate("DELETE FROM habitaciones WHERE usuario = \"" + textField.getText() + "\"");
						
						
						
					} catch (SQLException e3) {
						
						e3.printStackTrace();
					}
					
					
					dispose();
					UsuariosRegistrados2 us = new UsuariosRegistrados2();
					us.setVisible(true);
				} 
					 
			}else {
					
				
				JOptionPane.showMessageDialog(null, "El usuario no se encuentra en la base de datos ", "Pon un nuevo usuario",JOptionPane.WARNING_MESSAGE);
					
				}
				
				
				
				
				
				
				
				
			}
		});
		btnNewButton.setBackground(new Color(135, 206, 250));
		btnNewButton.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnNewButton.setBounds(606, 127, 129, 23);
		panel.add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(606, 179, 132, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		txtIntroduzcaElUsuario = new JTextField();
		txtIntroduzcaElUsuario.setForeground(new Color(255, 0, 0));
		txtIntroduzcaElUsuario.setBorder(null);
		txtIntroduzcaElUsuario.setEditable(false);
		txtIntroduzcaElUsuario.setBackground(new Color(135, 206, 250));
		txtIntroduzcaElUsuario.setText("Introduzca el usuario");
		txtIntroduzcaElUsuario.setBounds(616, 148, 138, 20);
		panel.add(txtIntroduzcaElUsuario);
		txtIntroduzcaElUsuario.setColumns(10);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnSalir.setBackground(new Color(135, 206, 250));
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(WIDTH);

			}
		});
		btnSalir.setBounds(658, 11, 89, 23);
		panel.add(btnSalir);
		
		txtQueQuieraBorrar = new JTextField();
		txtQueQuieraBorrar.setForeground(new Color(255, 0, 0));
		txtQueQuieraBorrar.setBorder(null);
		txtQueQuieraBorrar.setBackground(new Color(135, 206, 250));
		txtQueQuieraBorrar.setEditable(false);
		txtQueQuieraBorrar.setText("que quiera borrar");
		txtQueQuieraBorrar.setBounds(626, 161, 119, 20);
		panel.add(txtQueQuieraBorrar);
		txtQueQuieraBorrar.setColumns(10);
		
		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Actualizar2 a2 = new Actualizar2();
                a2.setVisible(true);

				
			}
		});
		btnActualizar.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnActualizar.setBounds(606, 236, 129, 23);
		panel.add(btnActualizar);
	}
}
