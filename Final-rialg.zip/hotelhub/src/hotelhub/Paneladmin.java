package hotelhub;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;

public class Paneladmin extends JFrame {

	private JPanel contentPane;
	private JTextField txtPanelDeAdmin;


	public Paneladmin() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(135, 206, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		
		
		JButton btnUsuariosRegistrados = new JButton("Usuarios Registrados");
		btnUsuariosRegistrados.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnUsuariosRegistrados.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				UsuariosRegistrados2 nuevaVentana = new UsuariosRegistrados2();
				nuevaVentana.setVisible(true);
				Paneladmin.this.dispose();					 

			}
		});
		btnUsuariosRegistrados.setBounds(128, 118, 182, 23);
		contentPane.add(btnUsuariosRegistrados);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(WIDTH);
				
			}
		});
		btnSalir.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnSalir.setBounds(168, 215, 110, 23);
		contentPane.add(btnSalir);
		
		txtPanelDeAdmin = new JTextField();
		txtPanelDeAdmin.setEditable(false);
		txtPanelDeAdmin.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtPanelDeAdmin.setForeground(new Color(0, 0, 0));
		txtPanelDeAdmin.setCaretColor(new Color(255, 255, 255));
		txtPanelDeAdmin.setBorder(null);
		txtPanelDeAdmin.setBackground(new Color(135, 206, 250));
		txtPanelDeAdmin.setText("PANEL DE ADMIN");
		txtPanelDeAdmin.setBounds(134, 11, 213, 20);
		contentPane.add(txtPanelDeAdmin);
		txtPanelDeAdmin.setColumns(10);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(76, 42, 271, 2);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(76, 202, 271, 2);
		contentPane.add(separator_1);
	}
}
