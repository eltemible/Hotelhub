package hotelhub;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPasswordField;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JMenu;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.DropMode;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.SpinnerNumberModel;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.ButtonGroup;
import javax.swing.border.TitledBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.JSeparator;
import javax.swing.JComboBox;

public class Habitaciones extends JFrame {

	private JPanel contentPane;
	private JTextField Ncamas;
	private JTextField txtTipoDeHabitacion;
	private JTextField txtextras;
	private JTextField txtDisfrutaDeTu;
	private JTextField txtHotelhub;
	private final ButtonGroup tipo = new ButtonGroup();
	private final ButtonGroup extras = new ButtonGroup();
	private JTextField nombre;
	private JTextField txtNombreDeUsuario_1;
	private JComboBox comboBox3;

	
	public Habitaciones() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 102, 255));
		contentPane.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Ncamas = new JTextField();
		Ncamas.setForeground(new Color(255, 255, 255));
		Ncamas.setBorder(null);
		Ncamas.setBackground(new Color(0, 102, 255));
		Ncamas.setEditable(false);
		Ncamas.setText("N\u00BAcamas");
		Ncamas.setBounds(185, 12, 86, 20);
		contentPane.add(Ncamas);
		Ncamas.setColumns(10);
		
		
		
		
		
		txtTipoDeHabitacion = new JTextField();
		txtTipoDeHabitacion.setForeground(new Color(255, 255, 255));
		txtTipoDeHabitacion.setBorder(null);
		txtTipoDeHabitacion.setBackground(new Color(0, 102, 255));
		txtTipoDeHabitacion.setEditable(false);
		txtTipoDeHabitacion.setText("Tipo de habitacion");
		txtTipoDeHabitacion.setBounds(14, 12, 125, 20);
		contentPane.add(txtTipoDeHabitacion);
		txtTipoDeHabitacion.setColumns(10);
		
		txtextras = new JTextField();
		txtextras.setForeground(new Color(255, 255, 255));
		txtextras.setDisabledTextColor(new Color(255, 255, 255));
		txtextras.setBorder(null);
		txtextras.setBackground(new Color(0, 102, 255));
		txtextras.setEditable(false);
		txtextras.setText("\u00BFExtras?");
		txtextras.setBounds(14, 76, 51, 20);
		contentPane.add(txtextras);
		txtextras.setColumns(10);
		
		txtDisfrutaDeTu = new JTextField();
		txtDisfrutaDeTu.setEditable(false);
		txtDisfrutaDeTu.setForeground(new Color(255, 255, 255));
		txtDisfrutaDeTu.setBackground(new Color(0, 102, 255));
		txtDisfrutaDeTu.setBorder(null);
		txtDisfrutaDeTu.setFont(new Font("Trajan Pro", Font.PLAIN, 15));
		txtDisfrutaDeTu.setText("DISFRUTA DE TU HABITACI\u00D3N");
		txtDisfrutaDeTu.setBounds(88, 176, 272, 20);
		contentPane.add(txtDisfrutaDeTu);
		txtDisfrutaDeTu.setColumns(10);
		
		txtHotelhub = new JTextField();
		txtHotelhub.setForeground(new Color(255, 255, 255));
		txtHotelhub.setEditable(false);
		txtHotelhub.setBorder(null);
		txtHotelhub.setBackground(new Color(0, 102, 255));
		txtHotelhub.setText("HOTELHUB");
		txtHotelhub.setBounds(185, 199, 86, 14);
		contentPane.add(txtHotelhub);
		txtHotelhub.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(14, 40, 105, 20);
		comboBox.addItem("Barato(10-25�)");
		comboBox.addItem("Normal(25-50�)");
		comboBox.addItem("Lujo(+100�)");

		contentPane.add(comboBox);
		
		JComboBox comboBox2 = new JComboBox();
		comboBox2.setBounds(14, 107, 51, 20);		
		comboBox2.addItem("Si");
		comboBox2.addItem("No");
		contentPane.add(comboBox2);				
		
		
		
		comboBox3 = new JComboBox();
		comboBox3.setBounds(185, 37, 45, 23);
		comboBox3.addItem("1");
		comboBox3.addItem("2");
		comboBox3.addItem("3");
		comboBox3.addItem("4");
		contentPane.add(comboBox3);
		
		//Reservar hotel
		
		
		//INSERT INTO `habitaciones` (`Ncamas`, `tipo`, `extras`, `usuario`) VALUES ('1', '2', 'Lujo', 'si', NULL)

		
		
		JButton btnReservar = new JButton("Reservar");
		btnReservar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				
//******************************************************//
					//ERROR
					//ERROR
					//ERROR


			Conexion c = new Conexion();
			c.Conectar();
			try {
				System.out.println("INSERT INTO habitaciones (tipo, extras, Ncamas, usuario) "
                        + "VALUES "
                        + "('" + comboBox.getSelectedItem() + 
                         "','" + comboBox2.getSelectedItem() + 
                         "','" + comboBox3.getSelectedItem() + 
                        "', '" + nombre.getText() +
                        "')");
				c.EjecutarUpdate("INSERT INTO habitaciones (tipo, extras, Ncamas, usuario) "
                        + "VALUES "
                        + "('" + comboBox.getSelectedItem() + 
                         "','" + comboBox2.getSelectedItem() + 
                         "','" + comboBox3.getSelectedItem() + 
                        "', '" + nombre.getText() +
                        "')");
				JOptionPane.showMessageDialog(null, "Su habitacion se ha reservado");

			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
					//ERROR
					//ERROR
					//ERROR

//******************************************************//

			
			}
		});
		btnReservar.setBounds(162, 237, 89, 23);
		contentPane.add(btnReservar);
		
		JButton btnNewButton = new JButton("Cerrar Sesion");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login nuevaVentana = new Login();
				nuevaVentana.setVisible(true);
				Habitaciones.this.dispose();
				
				
				
			}
		});
		btnNewButton.setBackground(new Color(0, 255, 255));
		btnNewButton.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnNewButton.setBounds(345, 11, 89, 23);
		contentPane.add(btnNewButton);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(84, 163, 263, 2);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(88, 224, 259, 2);
		contentPane.add(separator_1);
		
		nombre = new JTextField();
		nombre.setBounds(185, 107, 105, 20);
		contentPane.add(nombre);
		nombre.setColumns(10);
		
		txtNombreDeUsuario_1 = new JTextField();
		txtNombreDeUsuario_1.setForeground(new Color(255, 255, 255));
		txtNombreDeUsuario_1.setBorder(null);
		txtNombreDeUsuario_1.setBackground(new Color(0, 102, 255));
		txtNombreDeUsuario_1.setEditable(false);
		txtNombreDeUsuario_1.setText("Nombre de usuario");
		txtNombreDeUsuario_1.setBounds(185, 76, 125, 20);
		contentPane.add(txtNombreDeUsuario_1);
		txtNombreDeUsuario_1.setColumns(10);
		


		

		
		
		
		
		
	}
}
